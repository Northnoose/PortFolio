export default function ExperiencePage() {
  return (
    <main className="pt-24 px-6">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-bold">Experience</h1>
      </div>
    </main>
  )
}
