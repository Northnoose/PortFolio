export default function About() {
  return (
    <main className="pt-24 px-6">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-bold">About</h1>
      </div>
    </main>
  )
}
