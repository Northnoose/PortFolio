export const site = {
  name: "Your Name",
  title: "Your Name – Applied AI/ML Systems",
  description:
    "I build applied AI/ML systems in Python, focusing on reliable solutions with real-world impact.",
  url: "https://your-domain.com", // TODO: update when you have it
  twitterHandle: "@yourhandle", // optional
}
