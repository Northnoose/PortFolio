export const site = {
  name: "Your Name",
  title: "Your Name – Applied AI/ML Systems",
  description:
    "I build applied AI/ML systems in Python, focusing on reliable solutions with real-world impact.",
  url: "http://localhost:3000",
  twitterHandle: "@yourhandle", // optional
}
