import { Project } from "@/content/projects"
import { ProjectCard } from "@/components/cards/projectcard"
import { Reveal } from "@/components/motion/reveal"

type Props = {
  projects: Project[]
}

export function ProjectsGrid({ projects }: Props) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {projects.map((project) => (
        <Reveal key={project.slug}>
          <ProjectCard project={project} />
        </Reveal>
      ))}
    </div>
  )
}
