module.exports=[38285,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_robots_txt_route_actions_9118e90f.js.map