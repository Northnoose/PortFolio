module.exports=[9917,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_case-studies_%5Bslug%5D_page_actions_e5c7d8b2.js.map