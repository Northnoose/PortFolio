var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__a5eabd3d._.js")
R.c("server/chunks/[root-of-the-server]__c8b279f7._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_12658ace.js")
R.m(83345)
module.exports=R.m(83345).exports
