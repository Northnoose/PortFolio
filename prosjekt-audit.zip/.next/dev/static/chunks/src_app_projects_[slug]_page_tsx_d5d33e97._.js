(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_20ed78c4._.js",
  "static/chunks/src_components_motion_reveal_tsx_4f01d0b9._.js"
],
    source: "dynamic"
});
