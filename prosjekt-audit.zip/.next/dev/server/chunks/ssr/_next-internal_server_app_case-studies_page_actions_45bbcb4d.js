module.exports = [
"[project]/.next-internal/server/app/case-studies/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_case-studies_page_actions_45bbcb4d.js.map